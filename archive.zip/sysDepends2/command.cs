﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sysDepends2
{
    public class Dependancy
    {
        

    }
}
